// Diagnostik: simulasikan graph Canvas untuk compares sumber prompt
// (node 'prompt' vs node 'storyboard') lalu panggil resolveModelInputs asli.
import { resolveModelInputs } from '../src/lib/canvasRecipes';
import type { CanvasNode, CanvasEdge } from '../src/types/canvas';

const imageModelNode = (): CanvasNode => ({
  id: 'img1',
  type: 'imageModel',
  title: 'Banana Banana Pro',
  inputs: [
    { id: 'input-prompt', name: 'prompt', type: 'text', label: 'Prompt', required: true },
    { id: 'input-image', name: 'image_1', type: 'image', label: 'Image 1', required: false },
  ],
  outputs: [{ id: 'output-result', name: 'result', type: 'image', label: 'Generated Image' }],
  data: { modelId: 'fal-ai/nano-banana-pro/edit', provider: 'weavy', creditsCost: 11 },
} as any);

const promptNode = (): CanvasNode => ({
  id: 'p1',
  type: 'prompt',
  title: 'T Prompt',
  inputs: [],
  outputs: [{ id: 'output-text', name: 'text', type: 'text', label: 'Text' }],
  data: { prompt: 'pemandangan indah di kota bandung' },
} as any);

const storyboardNode = (opts: { scenes?: any[]; brief?: string }): CanvasNode => ({
  id: 'sb1',
  type: 'storyboard',
  title: 'Storyboard Copilot',
  inputs: [
    { id: 'input-brief', name: 'brief', type: 'text', label: 'Prompt', required: false },
  ],
  outputs: [],
  data: {
    brief: opts.brief ?? '',
    scenes: opts.scenes ?? [],
    aspectRatio: '9:16',
    targetDuration: 30,
  },
} as any);

const show = (label: string, r: any) => {
  console.log(`\n### ${label}`);
  console.log('  prompt  =', JSON.stringify(r.prompt));
  console.log('  length  =', (r.prompt || '').length);
  console.log('  imageUrls =', JSON.stringify(r.imageUrls));
};

const edge = (sourceOutputId: string, targetInputId: string): CanvasEdge => ({
  id: 'e1',
  sourceNodeId: 'src',
  sourceOutputId,
  targetNodeId: 'img1',
  targetInputId,
  color: '#000',
} as any);

// --- Kasus 1: sumber = prompt node (kasus yang berhasil di screenshot)
{
  const nodes = [promptNode(), imageModelNode()];
  const edges = [edge('output-text', 'input-prompt')];
  edges[0].sourceNodeId = 'p1';
  show('1. prompt node -> input-prompt', resolveModelInputs('img1', nodes, edges));
}

// --- Kasus 2: storyboard SUDAH generate (scenes ada, imagePrompt terisi)
{
  const scenes = [
    { sceneNumber: 1, title: 'Scene 1', visualDescription: 'Kota Bandung sore', voiceover: 'Halo', imagePrompt: 'cinematic cityscape of Bandung, golden hour, 8k' },
    { sceneNumber: 2, title: 'Scene 2', visualDescription: 'Kota Bandung malam', voiceover: 'Wow', imagePrompt: 'night cityscape of Bandung, 8k' },
  ];
  const nodes = [storyboardNode({ scenes, brief: 'brief storyboard' }), imageModelNode()];
  const edges = [edge('scene1_image', 'input-prompt')];
  edges[0].sourceNodeId = 'sb1';
  show('2. storyboard (scenes ada) -> input-prompt', resolveModelInputs('img1', nodes, edges));
}

// --- Kasus 3: storyboard dengan scenes tapi imagePrompt kosong
{
  const scenes = [
    { sceneNumber: 1, title: 'Scene 1', visualDescription: 'Kota Bandung sore', voiceover: 'Halo', imagePrompt: '' },
  ];
  const nodes = [storyboardNode({ scenes }), imageModelNode()];
  const edges = [edge('scene1_image', 'input-prompt')];
  edges[0].sourceNodeId = 'sb1';
  show('3. storyboard (imagePrompt kosong) -> input-prompt', resolveModelInputs('img1', nodes, edges));
}

// --- Kasus 4: storyboard BELUM generate (scenes kosong)
{
  const nodes = [storyboardNode({ scenes: [], brief: 'brief storyboard' }), imageModelNode()];
  const edges = [edge('scene1_image', 'input-prompt')];
  edges[0].sourceNodeId = 'sb1';
  show('4. storyboard (scenes kosong) -> input-prompt', resolveModelInputs('img1', nodes, edges));
}

// --- Kasus 5: storyboard scenes kosong DAN brief kosong
{
  const nodes = [storyboardNode({ scenes: [], brief: '' }), imageModelNode()];
  const edges = [edge('scene1_image', 'input-prompt')];
  edges[0].sourceNodeId = 'sb1';
  show('5. storyboard (scenes kosong, brief kosong) -> input-prompt', resolveModelInputs('img1', nodes, edges));
}

// --- Kasus 6: kabel nyangkut ke port Image 1 (bukan Prompt)
{
  const scenes = [
    { sceneNumber: 1, title: 'Scene 1', visualDescription: 'Kota Bandung sore', voiceover: 'Halo', imagePrompt: 'cinematic cityscape of Bandung, golden hour, 8k' },
  ];
  const nodes = [storyboardNode({ scenes }), imageModelNode()];
  const edges = [edge('scene1_image', 'input-image')];
  edges[0].sourceNodeId = 'sb1';
  show('6. storyboard -> input-image (kabel nyangkut port gambar)', resolveModelInputs('img1', nodes, edges));
}

// --- Kasus 7: node image model punya promptOverride (node hasil spawn dari storyboard)
{
  const scenes = [
    { sceneNumber: 1, title: 'Scene 1', visualDescription: 'Kota Bandung sore', voiceover: 'Halo', imagePrompt: 'cinematic cityscape of Bandung, golden hour, 8k' },
  ];
  const nodes = [storyboardNode({ scenes }), imageModelNode()];
  (nodes[1].data as any).promptOverride = 'cinematic cityscape of Bandung, golden hour, 8k';
  const edges = [edge('scene1_image', 'input-prompt')];
  edges[0].sourceNodeId = 'sb1';
  show('7. storyboard + promptOverride -> input-prompt', resolveModelInputs('img1', nodes, edges));
}
