"""gflow-cli — CLI and MCP server for Google Flow."""

__version__ = "0.85.0"
